//
//  TestDemoApp.swift
//  TestDemo
//
//  Created by GorCat on 2023/8/1.
//

import SwiftUI

@main
struct TestDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
